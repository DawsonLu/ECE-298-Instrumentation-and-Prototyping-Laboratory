var group__pmm__api =
[
    [ "PMM_calibrateReference", "group__pmm__api.html#ga08c76c1d306d70485f5c7c4c1da6b1c2", null ],
    [ "PMM_clearInterrupt", "group__pmm__api.html#gae2a8087c55cdfd5c2e271bbbdfb3b936", null ],
    [ "PMM_disableInterrupt", "group__pmm__api.html#ga86e4f2d43c21d73d5881bc0412d38125", null ],
    [ "PMM_enableInterrupt", "group__pmm__api.html#ga6ed9513c727882381aefc39f4dd55bc1", null ],
    [ "PMM_getInterruptStatus", "group__pmm__api.html#gadeacaacc7b13a0bfe5f52c1622a46d17", null ],
    [ "PMM_setRegulatorStatus", "group__pmm__api.html#gae567c48da39b55fb7d958c973acb8b7c", null ],
    [ "PMM_setupVoltageMonitor", "group__pmm__api.html#gaef97e5273a59d51136db985d0da6010e", null ],
    [ "PMM_unlockIOConfiguration", "group__pmm__api.html#ga6451428ecadfc4984da57afa49a0cb83", null ]
];