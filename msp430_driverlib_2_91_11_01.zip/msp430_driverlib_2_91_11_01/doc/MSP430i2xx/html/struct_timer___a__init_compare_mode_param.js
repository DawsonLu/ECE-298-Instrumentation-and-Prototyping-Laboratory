var struct_timer___a__init_compare_mode_param =
[
    [ "compareInterruptEnable", "struct_timer___a__init_compare_mode_param.html#a9b60b4a54a4c938ebc27eaff27e095c0", null ],
    [ "compareOutputMode", "struct_timer___a__init_compare_mode_param.html#ab56df34949c61bab44978b598194b8f6", null ],
    [ "compareRegister", "struct_timer___a__init_compare_mode_param.html#a30883dfcbf7070addb3efc4ac07e364d", null ],
    [ "compareValue", "struct_timer___a__init_compare_mode_param.html#af2a70cb7a6b22e87648b3f57085c9eab", null ]
];