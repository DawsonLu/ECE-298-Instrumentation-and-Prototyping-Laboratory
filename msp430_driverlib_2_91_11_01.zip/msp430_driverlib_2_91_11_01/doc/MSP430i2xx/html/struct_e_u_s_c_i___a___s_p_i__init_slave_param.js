var struct_e_u_s_c_i___a___s_p_i__init_slave_param =
[
    [ "clockPhase", "struct_e_u_s_c_i___a___s_p_i__init_slave_param.html#ab3e6980ef0c8f2690f62d663421cf12e", null ],
    [ "clockPolarity", "struct_e_u_s_c_i___a___s_p_i__init_slave_param.html#a7fd66f83ae925dd2ce59cb13c6450e85", null ],
    [ "msbFirst", "struct_e_u_s_c_i___a___s_p_i__init_slave_param.html#adb017c707e99e9f741ba0dd60bc850aa", null ],
    [ "spiMode", "struct_e_u_s_c_i___a___s_p_i__init_slave_param.html#a12f5090d6d7041adf018d4bec19152f0", null ]
];