var group__eusci__a__spi__api =
[
    [ "EUSCI_A_SPI_changeClockPhasePolarity", "group__eusci__a__spi__api.html#gae566374a62c75e9ea74cea2a84287226", null ],
    [ "EUSCI_A_SPI_changeMasterClock", "group__eusci__a__spi__api.html#gaede23884d973a7bcaf4203b39b1b0fdf", null ],
    [ "EUSCI_A_SPI_clearInterrupt", "group__eusci__a__spi__api.html#ga513190da61348db90178d928b4702b08", null ],
    [ "EUSCI_A_SPI_disable", "group__eusci__a__spi__api.html#ga9a75a79ce93830e157147b1eff1c82c9", null ],
    [ "EUSCI_A_SPI_disableInterrupt", "group__eusci__a__spi__api.html#gae09457b1e86177cf1433ab679de5cdb3", null ],
    [ "EUSCI_A_SPI_enable", "group__eusci__a__spi__api.html#ga887a169b3b6bb10316576f04a43e212d", null ],
    [ "EUSCI_A_SPI_enableInterrupt", "group__eusci__a__spi__api.html#ga0ee839fb097780ec312f65492a1712b0", null ],
    [ "EUSCI_A_SPI_getInterruptStatus", "group__eusci__a__spi__api.html#ga346b242110d8fa7117a30df56b43dfea", null ],
    [ "EUSCI_A_SPI_getReceiveBufferAddress", "group__eusci__a__spi__api.html#ga4e64e21421f0952074484ab116124d02", null ],
    [ "EUSCI_A_SPI_getTransmitBufferAddress", "group__eusci__a__spi__api.html#gac170dfce3401bd736c7eec0da58e494b", null ],
    [ "EUSCI_A_SPI_initMaster", "group__eusci__a__spi__api.html#ga28fac820247ff9eb27cea15e795c3f3c", null ],
    [ "EUSCI_A_SPI_initSlave", "group__eusci__a__spi__api.html#ga76ea4cbe0fcca41c1bcb70412c66f09e", null ],
    [ "EUSCI_A_SPI_isBusy", "group__eusci__a__spi__api.html#ga4c2a3af00d3f109afc6bbf6f98445a4d", null ],
    [ "EUSCI_A_SPI_receiveData", "group__eusci__a__spi__api.html#ga78ea9ababaf4161809dfa1de8bf5062f", null ],
    [ "EUSCI_A_SPI_select4PinFunctionality", "group__eusci__a__spi__api.html#ga1dcf1b6ffc00c7bba32425009cdd92a5", null ],
    [ "EUSCI_A_SPI_transmitData", "group__eusci__a__spi__api.html#gaad64c84c41eeed8eb2b391c5a5e4b88c", null ]
];