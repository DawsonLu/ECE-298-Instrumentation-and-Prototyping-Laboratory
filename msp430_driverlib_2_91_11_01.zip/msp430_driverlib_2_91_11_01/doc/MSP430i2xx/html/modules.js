var modules =
[
    [ "cs", "group__cs__api.html", "group__cs__api" ],
    [ "eusci_a_spi", "group__eusci__a__spi__api.html", "group__eusci__a__spi__api" ],
    [ "eusci_a_uart", "group__eusci__a__uart__api.html", "group__eusci__a__uart__api" ],
    [ "eusci_b_i2c", "group__eusci__b__i2c__api.html", "group__eusci__b__i2c__api" ],
    [ "eusci_b_spi", "group__eusci__b__spi__api.html", "group__eusci__b__spi__api" ],
    [ "flashctl", "group__flashctl__api.html", "group__flashctl__api" ],
    [ "gpio", "group__gpio__api.html", "group__gpio__api" ],
    [ "mpy", "group__mpy__api.html", "group__mpy__api" ],
    [ "pmm", "group__pmm__api.html", "group__pmm__api" ],
    [ "sd24", "group__sd24__api.html", "group__sd24__api" ],
    [ "sfr", "group__sfr__api.html", "group__sfr__api" ],
    [ "timer_a", "group__timer__a__api.html", "group__timer__a__api" ],
    [ "tlv", "group__tlv__api.html", "group__tlv__api" ],
    [ "wdt", "group__wdt__api.html", "group__wdt__api" ]
];