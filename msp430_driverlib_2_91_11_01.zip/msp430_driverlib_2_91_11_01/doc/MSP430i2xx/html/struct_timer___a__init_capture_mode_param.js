var struct_timer___a__init_capture_mode_param =
[
    [ "captureInputSelect", "struct_timer___a__init_capture_mode_param.html#a3a38dee2e7b9c75290a6a2b5769c0e59", null ],
    [ "captureInterruptEnable", "struct_timer___a__init_capture_mode_param.html#aa4baed37b508c4a900250c91dd9d43aa", null ],
    [ "captureMode", "struct_timer___a__init_capture_mode_param.html#a7f0272b437e9bed62a7d0e8cc7c10b20", null ],
    [ "captureOutputMode", "struct_timer___a__init_capture_mode_param.html#ad6a2ede6b3d5feca69775d1c2fd442a9", null ],
    [ "captureRegister", "struct_timer___a__init_capture_mode_param.html#ad5f959765ef1c471cce222562fd17040", null ],
    [ "synchronizeCaptureSource", "struct_timer___a__init_capture_mode_param.html#ab13d728ec678df4614b482d28fc0889a", null ]
];