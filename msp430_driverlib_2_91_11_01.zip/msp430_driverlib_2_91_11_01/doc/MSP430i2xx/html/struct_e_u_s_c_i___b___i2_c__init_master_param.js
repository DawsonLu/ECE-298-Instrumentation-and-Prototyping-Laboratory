var struct_e_u_s_c_i___b___i2_c__init_master_param =
[
    [ "autoSTOPGeneration", "struct_e_u_s_c_i___b___i2_c__init_master_param.html#a2843e828a718a228d7a7ac6d9f33ea44", null ],
    [ "byteCounterThreshold", "struct_e_u_s_c_i___b___i2_c__init_master_param.html#aac887a683d91a31d0338148a143028fc", null ],
    [ "dataRate", "struct_e_u_s_c_i___b___i2_c__init_master_param.html#a9fdb295485a86779f6460c5cf28c84b7", null ],
    [ "i2cClk", "struct_e_u_s_c_i___b___i2_c__init_master_param.html#aeafde0c1853ec0f646fc657de5071cc5", null ],
    [ "selectClockSource", "struct_e_u_s_c_i___b___i2_c__init_master_param.html#a00a91a5002aec80b79ab910141c6decd", null ]
];