var group__tlv__api =
[
    [ "TLV_getInfo", "group__tlv__api.html#gaf7a7d353cd48ce01f2f3854130221f69", null ],
    [ "TLV_performChecksumCheck", "group__tlv__api.html#ga15ea85d1758df08653a6ba8ddfe61151", null ]
];