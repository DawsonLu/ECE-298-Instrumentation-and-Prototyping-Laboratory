var annotated_dup =
[
    [ "EUSCI_A_SPI_changeMasterClockParam", "struct_e_u_s_c_i___a___s_p_i__change_master_clock_param.html", "struct_e_u_s_c_i___a___s_p_i__change_master_clock_param" ],
    [ "EUSCI_A_SPI_initMasterParam", "struct_e_u_s_c_i___a___s_p_i__init_master_param.html", "struct_e_u_s_c_i___a___s_p_i__init_master_param" ],
    [ "EUSCI_A_SPI_initSlaveParam", "struct_e_u_s_c_i___a___s_p_i__init_slave_param.html", "struct_e_u_s_c_i___a___s_p_i__init_slave_param" ],
    [ "EUSCI_A_UART_initParam", "struct_e_u_s_c_i___a___u_a_r_t__init_param.html", "struct_e_u_s_c_i___a___u_a_r_t__init_param" ],
    [ "EUSCI_B_I2C_initMasterParam", "struct_e_u_s_c_i___b___i2_c__init_master_param.html", "struct_e_u_s_c_i___b___i2_c__init_master_param" ],
    [ "EUSCI_B_I2C_initSlaveParam", "struct_e_u_s_c_i___b___i2_c__init_slave_param.html", "struct_e_u_s_c_i___b___i2_c__init_slave_param" ],
    [ "EUSCI_B_SPI_changeMasterClockParam", "struct_e_u_s_c_i___b___s_p_i__change_master_clock_param.html", "struct_e_u_s_c_i___b___s_p_i__change_master_clock_param" ],
    [ "EUSCI_B_SPI_initMasterParam", "struct_e_u_s_c_i___b___s_p_i__init_master_param.html", "struct_e_u_s_c_i___b___s_p_i__init_master_param" ],
    [ "EUSCI_B_SPI_initSlaveParam", "struct_e_u_s_c_i___b___s_p_i__init_slave_param.html", "struct_e_u_s_c_i___b___s_p_i__init_slave_param" ],
    [ "SD24_initConverterAdvancedParam", "struct_s_d24__init_converter_advanced_param.html", "struct_s_d24__init_converter_advanced_param" ],
    [ "Timer_A_initCaptureModeParam", "struct_timer___a__init_capture_mode_param.html", "struct_timer___a__init_capture_mode_param" ],
    [ "Timer_A_initCompareModeParam", "struct_timer___a__init_compare_mode_param.html", "struct_timer___a__init_compare_mode_param" ],
    [ "Timer_A_initContinuousModeParam", "struct_timer___a__init_continuous_mode_param.html", "struct_timer___a__init_continuous_mode_param" ],
    [ "Timer_A_initUpDownModeParam", "struct_timer___a__init_up_down_mode_param.html", "struct_timer___a__init_up_down_mode_param" ],
    [ "Timer_A_initUpModeParam", "struct_timer___a__init_up_mode_param.html", "struct_timer___a__init_up_mode_param" ],
    [ "Timer_A_outputPWMParam", "struct_timer___a__output_p_w_m_param.html", "struct_timer___a__output_p_w_m_param" ]
];