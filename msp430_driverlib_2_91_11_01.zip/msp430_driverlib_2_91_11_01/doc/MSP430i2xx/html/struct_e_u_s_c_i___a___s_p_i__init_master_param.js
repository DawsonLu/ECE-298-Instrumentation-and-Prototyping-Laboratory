var struct_e_u_s_c_i___a___s_p_i__init_master_param =
[
    [ "clockPhase", "struct_e_u_s_c_i___a___s_p_i__init_master_param.html#ae1b0f6e5c4739935f65ffad39e3b6a59", null ],
    [ "clockPolarity", "struct_e_u_s_c_i___a___s_p_i__init_master_param.html#a0f3ff944b362aa3aa3cdf56b4829293e", null ],
    [ "clockSourceFrequency", "struct_e_u_s_c_i___a___s_p_i__init_master_param.html#a17cc422191818cdc2690507fbc9a9261", null ],
    [ "desiredSpiClock", "struct_e_u_s_c_i___a___s_p_i__init_master_param.html#a78752d05c1b2a78815819152e7845945", null ],
    [ "msbFirst", "struct_e_u_s_c_i___a___s_p_i__init_master_param.html#a67c8dc4aae17ddeb3dc1f59a09d79546", null ],
    [ "selectClockSource", "struct_e_u_s_c_i___a___s_p_i__init_master_param.html#a9f6e5c38ade25f458c1e93e091f0e230", null ],
    [ "spiMode", "struct_e_u_s_c_i___a___s_p_i__init_master_param.html#a7ab28f54ac728ca6a93be9d9f8c6af93", null ]
];