var group__cs__api =
[
    [ "CS_getACLK", "group__cs__api.html#ga0fa3d27598e86f1098a96dd041673141", null ],
    [ "CS_getFaultFlagStatus", "group__cs__api.html#ga2a26c1bdfeffc3b11431fd811d50db68", null ],
    [ "CS_getMCLK", "group__cs__api.html#ga2e02ddb15b854383842bbc8f52fa050d", null ],
    [ "CS_getSMCLK", "group__cs__api.html#gae012353ccb47ae03e7b0939a12d79c3c", null ],
    [ "CS_initClockSignal", "group__cs__api.html#gaacb4bb97973970562e5a8b97690c6bdd", null ],
    [ "CS_setupDCO", "group__cs__api.html#gafdd5b4799655611e9eda3e9407447233", null ]
];