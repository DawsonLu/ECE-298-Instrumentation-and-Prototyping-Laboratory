var struct_s_d24__init_converter_advanced_param =
[
    [ "conversionMode", "struct_s_d24__init_converter_advanced_param.html#a8440a293209038d47172687f95844b21", null ],
    [ "converter", "struct_s_d24__init_converter_advanced_param.html#acc3f898c7fe92a9f1d3da9f6846f4779", null ],
    [ "dataFormat", "struct_s_d24__init_converter_advanced_param.html#a1baea59bb35a6baec330b6f0446fb36d", null ],
    [ "gain", "struct_s_d24__init_converter_advanced_param.html#adf121f01a958b632ac7ab6222db8133c", null ],
    [ "groupEnable", "struct_s_d24__init_converter_advanced_param.html#a1e394cadb94ef0c77b374be09759f082", null ],
    [ "inputChannel", "struct_s_d24__init_converter_advanced_param.html#a844f85e0643fe6c2532a8a4a04cad4e7", null ],
    [ "interruptDelay", "struct_s_d24__init_converter_advanced_param.html#a185ff0aeec46f71235eb64f7b64d28fd", null ],
    [ "oversampleRatio", "struct_s_d24__init_converter_advanced_param.html#afbec3393c8a4b4a882cba51b8981e601", null ]
];