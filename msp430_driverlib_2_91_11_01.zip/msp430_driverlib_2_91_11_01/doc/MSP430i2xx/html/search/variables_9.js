var searchData=
[
  ['oversampleratio',['oversampleRatio',['../struct_s_d24__init_converter_advanced_param.html#afbec3393c8a4b4a882cba51b8981e601',1,'SD24_initConverterAdvancedParam']]],
  ['oversampling',['overSampling',['../struct_e_u_s_c_i___a___u_a_r_t__init_param.html#a21d7b3a1ea9a1515d05b5bca3557153c',1,'EUSCI_A_UART_initParam']]]
];
