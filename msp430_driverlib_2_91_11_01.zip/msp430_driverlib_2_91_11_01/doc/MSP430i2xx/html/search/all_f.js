var searchData=
[
  ['wdt',['wdt',['../group__wdt__api.html',1,'']]],
  ['wdt_5fhold',['WDT_hold',['../group__wdt__api.html#gacb866492ef1080c1cd8cc15257cfc1fb',1,'WDT_hold(uint16_t baseAddress):&#160;wdt.c'],['../group__wdt__api.html#gacb866492ef1080c1cd8cc15257cfc1fb',1,'WDT_hold(uint16_t baseAddress):&#160;wdt.c']]],
  ['wdt_5finitintervaltimer',['WDT_initIntervalTimer',['../group__wdt__api.html#ga3c98d14344472b44823ef32dba4e77ab',1,'WDT_initIntervalTimer(uint16_t baseAddress, uint8_t clockSelect, uint8_t clockDivider):&#160;wdt.c'],['../group__wdt__api.html#ga3c98d14344472b44823ef32dba4e77ab',1,'WDT_initIntervalTimer(uint16_t baseAddress, uint8_t clockSelect, uint8_t clockDivider):&#160;wdt.c']]],
  ['wdt_5finitwatchdogtimer',['WDT_initWatchdogTimer',['../group__wdt__api.html#gaca93d106501ca804ae34739201f078fe',1,'WDT_initWatchdogTimer(uint16_t baseAddress, uint8_t clockSelect, uint8_t clockDivider):&#160;wdt.c'],['../group__wdt__api.html#gaca93d106501ca804ae34739201f078fe',1,'WDT_initWatchdogTimer(uint16_t baseAddress, uint8_t clockSelect, uint8_t clockDivider):&#160;wdt.c']]],
  ['wdt_5fresettimer',['WDT_resetTimer',['../group__wdt__api.html#ga178aad249db559a554e735a8d2c9ed02',1,'WDT_resetTimer(uint16_t baseAddress):&#160;wdt.c'],['../group__wdt__api.html#ga178aad249db559a554e735a8d2c9ed02',1,'WDT_resetTimer(uint16_t baseAddress):&#160;wdt.c']]],
  ['wdt_5fstart',['WDT_start',['../group__wdt__api.html#ga249b2a956b45cac9928ce89b88b86378',1,'WDT_start(uint16_t baseAddress):&#160;wdt.c'],['../group__wdt__api.html#ga249b2a956b45cac9928ce89b88b86378',1,'WDT_start(uint16_t baseAddress):&#160;wdt.c']]]
];
