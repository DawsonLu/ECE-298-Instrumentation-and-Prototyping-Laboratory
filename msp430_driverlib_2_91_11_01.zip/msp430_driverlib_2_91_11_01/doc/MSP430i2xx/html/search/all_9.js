var searchData=
[
  ['numberofstopbits',['numberofStopBits',['../struct_e_u_s_c_i___a___u_a_r_t__init_param.html#a6bd549035e2573a6d6b7d679a155e39e',1,'EUSCI_A_UART_initParam']]]
];
