var searchData=
[
  ['parity',['parity',['../struct_e_u_s_c_i___a___u_a_r_t__init_param.html#a32784a9ee7ce0cdf1fd058da28c414aa',1,'EUSCI_A_UART_initParam']]]
];
