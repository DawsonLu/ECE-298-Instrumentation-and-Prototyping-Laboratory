var searchData=
[
  ['gain',['gain',['../struct_s_d24__init_converter_advanced_param.html#adf121f01a958b632ac7ab6222db8133c',1,'SD24_initConverterAdvancedParam']]],
  ['groupenable',['groupEnable',['../struct_s_d24__init_converter_advanced_param.html#a1e394cadb94ef0c77b374be09759f082',1,'SD24_initConverterAdvancedParam']]]
];
