var group__mpy__api =
[
    [ "MPY_getResult", "group__mpy__api.html#gaf49a627feb176fda93ed9aeacea9aa32", null ],
    [ "MPY_getSumExtension", "group__mpy__api.html#ga4a4abd9b99b8299c22f66f10e932bf8a", null ],
    [ "MPY_setOperandOne16Bit", "group__mpy__api.html#gad46fae9ab06900286ef2d41f4f78cb95", null ],
    [ "MPY_setOperandOne8Bit", "group__mpy__api.html#gaa414a6cc6a5660c58fa50cfe16af8f84", null ],
    [ "MPY_setOperandTwo16Bit", "group__mpy__api.html#ga83f777966a9c5e2c71f25c8bd6c99410", null ],
    [ "MPY_setOperandTwo8Bit", "group__mpy__api.html#gaeaec9cb8949018178dbcb6879b6019f7", null ]
];